#include <iostream>
#include <fstream>
using namespace std;

class zg{

public:
	zg();
	void new_writer(char gh[10], char name[10], float gwgz[10], float xjgz[10], float zwgz[10], float jxgz[10], float yfgz[10], float sds[10], float sfgz[10]);
	void disp();
	void getname();
private:

	char gh[10];
	char name[10];
	float gwgz[10], xjgz[10], zwgz[10], jxgz[10], yfgz[10], sds[10], sfgz[10];

};
void read()
{
	file *p;
	struct new_writer;
	if ((fp = fopen("gz.dat", )) == NULL)
	{
		printf("�ļ���ʧ��");
		return 0;
	}
	while (!feof(fp))
	{
		fscanf(fp);
	}
